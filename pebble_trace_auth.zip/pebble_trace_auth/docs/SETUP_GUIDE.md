# Google Play Games Services + Firebase Auth
## Complete Setup Guide for Godot 4.5

---

## Overview of What You're Building

```
[Your Game] → [AuthFlowManager] → [GPGS Plugin] → [Google Servers]
                      ↓
              [godot-firebase] → [Firebase Auth] → [Firebase Session]
```

The flow:
1. Player taps "Sign in with Play Games"
2. GPGS returns a **Server Auth Code** (not an ID token)
3. Your game sends the code to Firebase using `code=` (OAuth spec)
4. Firebase validates with Google and returns a session token
5. Your game receives a Firebase UID and user data

---

## Prerequisites Checklist

- [ ] Godot 4.5 installed
- [ ] Android SDK + JDK installed (for Android export)
- [ ] A Google Play Console account
- [ ] A Firebase project
- [ ] Your game APK signed with a release keystore

---

## Step 1 — Firebase Setup

### 1a. Create a Firebase Project
1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → name it (e.g., "PebbleTrace")
3. Enable Google Analytics if desired → **Create project**

### 1b. Add Android App to Firebase
1. In Firebase Console → **Project Overview** → **Add app** → Android icon
2. Enter your **Android package name** (must match exactly, e.g., `com.yourcompany.yourgame`)
3. Enter your app nickname
4. Enter your **SHA-1 fingerprint** (from your release keystore):
   ```bash
   keytool -list -v -keystore your-release-key.jks -alias your-key-alias
   ```
5. Download `google-services.json` → place it in your Godot project root as **`firebase_config.json`**
   > godot-firebase uses `firebase_config.json`, NOT `google-services.json` directly

### 1c. Enable Firebase Authentication
1. Firebase Console → **Authentication** → **Get started**
2. Go to **Sign-in method** tab
3. Enable **Anonymous** (for guest mode)
4. Enable **Play Games** under "Additional providers"
   - You'll need to fill in the OAuth 2.0 Web Client ID (get this in Step 2)

### 1d. Convert google-services.json to firebase_config.json
Run this or manually map the fields:
```python
import json

with open("google-services.json") as f:
	gs = json.load(f)

client = gs["client"][0]
firebase_config = {
	"apiKey": client["api_key"][0]["current_key"],
	"authDomain": gs["project_info"]["project_id"] + ".firebaseapp.com",
	"databaseURL": "https://" + gs["project_info"]["project_id"] + "-default-rtdb.firebaseio.com",
	"projectId": gs["project_info"]["project_id"],
	"storageBucket": gs["project_info"]["storage_bucket"],
	"messagingSenderId": gs["project_info"]["project_number"],
	"appId": client["client_info"]["mobilesdk_app_id"]
}

with open("firebase_config.json", "w") as f:
	json.dump(firebase_config, f, indent=2)

print("Done! firebase_config.json created.")
```

---

## Step 2 — Google Cloud Console & OAuth Setup

### 2a. Get the Web Client ID (CRITICAL)

> ⚠️ You MUST use the **Web Client ID**, NOT the Android Client ID.
> Using the wrong ID is the #1 cause of empty auth codes.

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Select your Firebase project (same project ID)
3. Navigate to **APIs & Services** → **Credentials**
4. Look for an OAuth 2.0 Client ID of type **"Web application"**
   - Firebase automatically creates one — it will be named something like "Web client (auto created by Google Service)"
5. Copy the **Client ID** — it looks like: `123456789-abcdefg.apps.googleusercontent.com`

### 2b. OAuth Consent Screen
If not already configured:
1. **APIs & Services** → **OAuth consent screen**
2. Set User Type to **External** (or Internal for testing)
3. Fill in App name, support email
4. Add scopes: `openid`, `email`, `profile`
5. Add your test email addresses under "Test users"
6. Save and publish (or keep in Testing mode for development)

---

## Step 3 — Play Console Setup (matches your screenshot)

From your Play Console screenshot, you're at step 2 of 6. Here's what to complete:

### 3a. Create OAuth Consent Screen in Google Cloud Platform ✓
(Done in Step 2b above)

### 3b. Create Credentials
1. In Play Console → **Play Games Services** → **Setup and management** → **Configuration**
2. Click **Add credential**
3. Select **Android** as the OAuth client type
4. Select your Android OAuth client from the dropdown
   (If not listed, create one in Google Cloud Console → Android type)
5. Also add a **Web** credential using the Web Client ID from Step 2a

### 3c. Add SDK to Production APK
1. Export your Godot game as a signed APK
2. Upload it to Play Console (Internal Testing track is fine)
3. Come back to Play Games Services configuration
4. Click **Add the Play Games Services SDK to your production APK**
5. Select your uploaded APK

### 3d. Link Firebase ← Fix "Firebase not linked" warning
1. In Play Console → Play Games Services configuration
2. Click **Edit properties**
3. In the Firebase section, click **Link to Firebase**
4. Select your Firebase project
5. This is important — linking enables the token exchange to work

### 3e. Publish the Configuration
1. Click **Review and publish** (top right in your screenshot)
2. This makes GPGS available to your testers

---

## Step 4 — Godot Plugin Installation

### 4a. Install godot-firebase
```
Project root/
  addons/
	godot-firebase/        ← clone from github.com/GodotNuts/GodotFirebase
```
Enable in **Project → Project Settings → Plugins**

### 4b. Install GodotPlayGameServices
```
Project root/
  addons/
	GodotPlayGameServices/ ← from github.com/Iakobs/godot-play-game-services
```
Enable in **Project → Project Settings → Plugins**

### 4c. Install This Plugin (PlayGamesFirebaseAuth)
Copy the `addons/PlayGamesFirebaseAuth/` folder to your project.
Enable in **Project → Project Settings → Plugins**

---

## Step 5 — Code Setup

### 5a. Apply the Firebase Auth Patch

Open `addons/godot-firebase/auth/auth.gd`

Find the `login_with_google_play` function and change:
```gdscript
# ❌ WRONG - causes INVALID_CREDENTIAL_OR_PROVIDER_ID
_oauth_login_request_body.postBody = "serverAuthCode=" + auth_code + "&providerId=playgames.google.com"
```
To:
```gdscript
# ✅ CORRECT - OAuth 2.0 spec compliance
_oauth_login_request_body.postBody = "code=" + auth_code.uri_encode() + "&providerId=playgames.google.com"
_oauth_login_request_body.returnIdpCredential = true
```

### 5b. Replace sign_in_client.gd

Replace `addons/GodotPlayGameServices/scripts/sign_in/sign_in_client.gd`
with the version from `addons/PlayGamesFirebaseAuth/scripts/sign_in_client.gd`

This fixes the Android → GDScript signal bridging.

### 5c. Set Your Web Client ID

Open `Scripts/Backend/AuthFlowManager.gd`, line ~22:
```gdscript
const WEB_CLIENT_ID: String = "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com"
#                              ↑ Replace this with your actual Web Client ID
```

### 5d. Configure Autoloads

Go to **Project → Project Settings → Autoload**, add in this order:
| Name | Path |
|------|------|
| `Firebase` | `res://addons/godot-firebase/Firebase.gd` |
| `FirebaseInitializer` | `res://Scripts/Backend/FirebaseInitializer.gd` |
| `AuthFlowManager` | `res://Scripts/Backend/AuthFlowManager.gd` |

### 5e. Configure Android Export

In **Project → Export → Android**:
1. Under **Plugins**, enable: `GodotPlayGameServices`
2. Set your keystore (release key, not debug!)
3. Set your package name to match Firebase

---

## Step 6 — Testing

### 6a. Add Yourself as a Tester
1. Play Console → **Play Games Services** → **Testers**
2. Add your Google account email
3. This is required for GPGS to work before publishing

### 6b. Test the Auth Flow

Add this to any node's `_ready()` for a quick test:
```gdscript
func _ready() -> void:
    AuthFlowManager.auth_succeeded.connect(func(user):
        print("SUCCESS! UID: ", user.uid)
        print("Provider: ", user.provider)
    )
    AuthFlowManager.auth_failed.connect(func(reason):
        print("FAILED: ", reason)
    )
    # Trigger sign in
    AuthFlowManager.sign_in_with_play_games()
```

### 6c. Check Firebase Console

After successful sign-in, go to:
**Firebase Console → Authentication → Users**

You should see a new user appear with:
- Provider: `playgames.google.com`
- A Firebase UID
- (Not anonymous)

---

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| Empty auth code | Wrong Client ID type | Use **Web** Client ID, not Android |
| `INVALID_CREDENTIAL_OR_PROVIDER_ID` | Wrong postBody key | Change `serverAuthCode=` to `code=` |
| `serverSideAccessRequested` never fires | Signal not bridged | Use the patched `sign_in_client.gd` |
| `Firebase not linked` warning | Play Console not linked | Link Firebase in Play Console properties |
| User shows as Anonymous | Code flow not reached | Check logcat for plugin errors |
| No users in Firebase Console | Auth never completed | Verify Firebase Auth → Play Games is enabled |

### Enable Logcat Filtering
When testing on device, filter logcat by:
```
adb logcat -s "godot:*" "GodotPlayGameServices:*" "AuthFlowManager:*"
```

---

## File Structure Summary

```
YourProject/
├── addons/
│   ├── godot-firebase/           (external - install from GitHub)
│   │   └── auth/auth.gd          ← PATCH: change serverAuthCode= to code=
│   ├── GodotPlayGameServices/    (external - install from GitHub)
│   │   └── scripts/sign_in/
│   │       └── sign_in_client.gd ← REPLACE with our version
│   └── PlayGamesFirebaseAuth/    (this plugin)
│       ├── plugin.cfg
│       ├── plugin.gd
│       └── scripts/
│           ├── sign_in_client.gd     (replacement for GPGS plugin)
│           └── firebase_auth_patch.gd (documentation)
├── Scripts/
│   ├── Backend/
│   │   ├── AuthFlowManager.gd    ← Autoload #3
│   │   └── FirebaseInitializer.gd ← Autoload #2
│   └── UI/
│       └── signup_popup.gd       ← Example UI controller
├── firebase_config.json          ← Your Firebase config
└── project.godot                 ← Autoload config
```
