# ==============================================================================
# AuthFlowManager.gd
# Path: Scripts/Backend/AuthFlowManager.gd
#
# PURPOSE:
#   Central hub for all authentication logic. Handles:
#     - Anonymous sign-in (default / guest mode)
#     - Google Play Games Services (GPGS) sign-in on Android
#     - Firebase Auth token exchange via godot-firebase addon
#
# SIGNALS (listen to these from your UI):
#   auth_succeeded(user_data: Dictionary)  -> fired when any auth method works
#   auth_failed(reason: String)            -> fired on any failure
#   auth_state_changed(is_signed_in: bool) -> fired when sign-in state changes
#
# USAGE:
#   1. Autoload this script as "AuthFlowManager"
#   2. Connect signals in your UI scripts
#   3. Call sign_in_with_play_games() or sign_in_anonymously()
# ==============================================================================

extends Node

# ── Signals ───────────────────────────────────────────────────────────────────
signal auth_succeeded(user_data: Dictionary)
signal auth_failed(reason: String)
signal auth_state_changed(is_signed_in: bool)

# ── Constants ─────────────────────────────────────────────────────────────────
## IMPORTANT: Replace with your Web Client ID from Google Cloud Console.
## This must be the WEB client ID (not the Android client ID).
## Found at: Google Cloud Console → APIs & Services → Credentials
const WEB_CLIENT_ID: String = "686028737770-m7f2uni6ab3qrhilrhjhl37o5q919kf1.apps.googleusercontent.com"

## Timeout (seconds) to wait for GPGS to return an auth code
const AUTH_TIMEOUT_SECONDS: float = 30.0

# ── State ─────────────────────────────────────────────────────────────────────
var _sign_in_client = null        # PlayGamesSignInClient instance
var _is_authenticated: bool = false
var _current_user: Dictionary = {}
var _auth_resolve: Signal         # used internally for async waiting

# ── Lifecycle ─────────────────────────────────────────────────────────────────
func _ready() -> void:
	_connect_firebase_signals()
	print("[AuthFlowManager] Ready. Platform: %s" % OS.get_name())


# ==============================================================================
# PUBLIC API
# ==============================================================================

## Returns true if there is a currently authenticated user
func is_authenticated() -> bool:
	return _is_authenticated

## Returns the current user data dict, or empty dict if not signed in
func get_current_user() -> Dictionary:
	return _current_user


## Starts the Play Games sign-in flow (Android only).
## Falls back to anonymous sign-in on other platforms.
## Awaitable: returns true on success, false on failure.
func sign_in_with_play_games() -> bool:

	if OS.get_name() != "Android":
		push_warning("[AuthFlowManager] Play Games login only works on Android.")
		auth_failed.emit("Play Games login only works on Android.")
		return false

	return await _android_play_games_sign_in()
	
## Signs the user in anonymously via Firebase.
## Awaitable: returns true on success, false on failure.
func sign_in_anonymously() -> bool:
	print("[AuthFlowManager] Attempting anonymous sign-in...")
	if not _check_firebase():
		return false

	Firebase.Auth.login_anonymous()
	var result = await _wait_for_firebase_response()
	return result


## Signs the current user out of Firebase (and GPGS if available).
func sign_out() -> void:
	print("[AuthFlowManager] Signing out...")
	if _check_firebase():
		Firebase.Auth.logout()
	_clear_user_state()
	auth_state_changed.emit(false)


# ==============================================================================
# ANDROID / GPGS INTERNALS
# ==============================================================================

func _android_play_games_sign_in() -> bool:
	print("[AuthFlowManager] Starting GPGS sign-in flow...")

	if not _setup_gpgs():
		auth_failed.emit("Failed to initialize Google Play Games Services plugin.")
		return false

	# Request the Server Auth Code (requires Web Client ID, NOT Android Client ID)
	_sign_in_client.request_server_side_access(WEB_CLIENT_ID, false)
	print("[AuthFlowManager] Waiting for auth code from GPGS...")

	# Wait for the code with a timeout
	var code = await _wait_for_auth_code()

	if code.is_empty():
		auth_failed.emit("GPGS did not return an auth code (timeout or user cancelled).")
		return false

	print("[AuthFlowManager] Auth code received. Sending to Firebase...")
	return await _exchange_code_with_firebase(code)


## Initialises the GPGS plugin and wires up signals.
## Returns false if the plugin is unavailable.
func _setup_gpgs() -> bool:
	if _sign_in_client != null:
		return true  # already set up

	if not ClassDB.class_exists("GodotPlayGameServices"):
		push_error("[AuthFlowManager] GodotPlayGameServices plugin not found. Is it enabled?")
		return false

	var status = GodotPlayGameServices.initialize()
	if status != GodotPlayGameServices.PlayGamesPluginError.OK:
		push_error("[AuthFlowManager] GodotPlayGameServices.initialize() failed: %s" % status)
		return false

	# Dynamically load the sign-in client class
	var SignInClientScript = load("res://addons/GodotPlayGameServices/scripts/sign_in/sign_in_client.gd")
	if SignInClientScript == null:
		push_error("[AuthFlowManager] Could not load sign_in_client.gd. Check the plugin path.")
		return false

	_sign_in_client = SignInClientScript.new()
	add_child(_sign_in_client)

	# Connect the signal that delivers the server auth code
	if not _sign_in_client.server_side_access_requested.is_connected(_on_gpgs_code_received):
		_sign_in_client.server_side_access_requested.connect(_on_gpgs_code_received)

	print("[AuthFlowManager] GPGS plugin initialized successfully.")
	return true


## Internal: waits for GPGS to emit the auth code, with timeout.
func _wait_for_auth_code() -> String:
	var code: String = ""
	var timed_out: bool = false

	# One-shot wrapper: listens for either the code or a timeout
	var timer := get_tree().create_timer(AUTH_TIMEOUT_SECONDS)

	# Use a local signal to bridge the async gap
	var received_code := Signal(_sign_in_client, "server_side_access_requested")

	var result = await _race_signals(received_code, timer.timeout)

	if result is String:
		code = result
	# else timed out → code stays empty

	return code


## Races two signals; returns the value from whichever fires first.
## val_a is the winning value if signal_a fires, null if signal_b fires first.
func _race_signals(signal_a: Signal, signal_b: Signal) -> Variant:
	var winner = null
	var done = false

	var cb_a = func(val):
		if not done:
			done = true
			winner = val

	var cb_b = func():
		if not done:
			done = true
			winner = null

	signal_a.connect(cb_a, CONNECT_ONE_SHOT)
	signal_b.connect(cb_b, CONNECT_ONE_SHOT)

	# Spin until one fires
	while not done:
		await get_tree().process_frame

	return winner


# Called when GPGS emits the server auth code
func _on_gpgs_code_received(auth_code: String) -> void:
	print("========== GPGS CODE RECEIVED ==========")
	print(auth_code)
	print("EMPTY?: ", auth_code.is_empty())


## Sends the GPGS server auth code to Firebase for exchange
func _exchange_code_with_firebase(auth_code: String) -> bool:
	if not _check_firebase():
		return false

	# This calls the modified login_with_google_play in the firebase addon
	Firebase.Auth.login_with_google_play(auth_code)
	print("[AuthFlowManager] Code sent to Firebase. Waiting for response...")
	return await _wait_for_firebase_response()


# ==============================================================================
# FIREBASE SIGNAL HANDLING
# ==============================================================================

func _connect_firebase_signals() -> void:
	if not _check_firebase():
		return

	if not Firebase.Auth.login_succeeded.is_connected(_on_firebase_login_succeeded):
		Firebase.Auth.login_succeeded.connect(_on_firebase_login_succeeded)

	if not Firebase.Auth.login_failed.is_connected(_on_firebase_login_failed):
		Firebase.Auth.login_failed.connect(_on_firebase_login_failed)

	print("[AuthFlowManager] Firebase signals connected.")


func _wait_for_firebase_response() -> bool:
	var done = false
	var success = false

	var on_success = func(user_data):
		if not done:
			done = true
			success = true

	var on_fail = func(code, message):
		if not done:
			done = true
			success = false

	Firebase.Auth.login_succeeded.connect(on_success, CONNECT_ONE_SHOT)
	Firebase.Auth.login_failed.connect(on_fail, CONNECT_ONE_SHOT)

	var timer := get_tree().create_timer(AUTH_TIMEOUT_SECONDS)
	timer.timeout.connect(func():
		if not done:
			done = true
			success = false
	, CONNECT_ONE_SHOT)

	while not done:
		await get_tree().process_frame

	return success


func _on_firebase_login_succeeded(user_data) -> void:
	print("[AuthFlowManager] Firebase login succeeded!")
	_is_authenticated = true
	_current_user = {
		"uid": user_data.localId if "localId" in user_data else "",
		"email": user_data.email if "email" in user_data else "",
		"display_name": user_data.displayName if "displayName" in user_data else "Player",
		"provider": user_data.providerId if "providerId" in user_data else "anonymous",
		"id_token": user_data.idToken if "idToken" in user_data else "",
		"refresh_token": user_data.refreshToken if "refreshToken" in user_data else "",
	}
	auth_succeeded.emit(_current_user)
	auth_state_changed.emit(true)


func _on_firebase_login_failed(error_code, message) -> void:
	push_error("[AuthFlowManager] Firebase login failed [%s]: %s" % [error_code, message])
	_is_authenticated = false
	auth_failed.emit("Firebase error %s: %s" % [error_code, message])
	auth_state_changed.emit(false)


# ==============================================================================
# HELPERS
# ==============================================================================

func _check_firebase() -> bool:
	if Firebase == null:
		push_error("[AuthFlowManager] Firebase autoload not found.")
		return false

	if Firebase.Auth == null:
		push_error("[AuthFlowManager] Firebase.Auth not initialized.")
		return false

	return true

func _clear_user_state() -> void:
	_is_authenticated = false
	_current_user = {}
