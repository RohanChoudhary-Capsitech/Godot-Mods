# ==============================================================================
# FirebaseInitializer.gd
# Path: Scripts/Backend/FirebaseInitializer.gd
#
# PURPOSE:
#   Ensures Firebase is fully initialized before any auth calls are made.
#   Add this as an Autoload BEFORE AuthFlowManager in Project Settings.
#
# AUTOLOAD ORDER (Project → Project Settings → Autoload):
#   1. Firebase          (from godot-firebase addon)
#   2. FirebaseInitializer
#   3. AuthFlowManager
# ==============================================================================

extends Node

signal firebase_ready
signal firebase_failed(reason: String)

var _is_ready: bool = false

func _ready() -> void:
	print("[FirebaseInitializer] Waiting for Firebase to initialize...")
	_wait_for_firebase()


func _wait_for_firebase() -> void:
	# Firebase needs a frame to initialize its HTTP client and load config
	await get_tree().process_frame
	await get_tree().process_frame

	if _check_firebase_config():
		_is_ready = true
		print("[FirebaseInitializer] Firebase is ready.")
		firebase_ready.emit()
	else:
		push_error("[FirebaseInitializer] Firebase initialization failed.")
		firebase_failed.emit("Firebase config not found or invalid.")


func _check_firebase_config() -> bool:
	# Verify the firebase config file exists
	if not FileAccess.file_exists("res://firebase_config.json") and \
	   not FileAccess.file_exists("res://google-services.json"):
		push_error("[FirebaseInitializer] No firebase_config.json or google-services.json found!")
		return false
	return true


func is_ready() -> bool:
	return _is_ready


## Call this and await it to ensure Firebase is ready before auth
func wait_until_ready() -> void:
	if _is_ready:
		return
	await firebase_ready
