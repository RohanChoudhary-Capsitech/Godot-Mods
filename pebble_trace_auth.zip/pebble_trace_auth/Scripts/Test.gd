
extends Node

func _ready():

	AuthFlowManager.auth_succeeded.connect(func(user):
		print("AUTH SUCCESS")
		print(user)
	)

	AuthFlowManager.auth_failed.connect(func(reason):
		print("AUTH FAILED")
		print(reason)
	)

	if OS.get_name() == "Android":
		await AuthFlowManager.sign_in_with_play_games()
	else:
		await AuthFlowManager.sign_in_anonymously()
