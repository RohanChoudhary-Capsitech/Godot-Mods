# ==============================================================================
# signup_popup.gd
# Path: Scripts/UI/signup_popup.gd
#
# PURPOSE:
#   Example UI controller for a sign-in popup.
#   Attach to a CanvasLayer or Control node that has:
#     - A Button named "PlayGamesButton"
#     - A Button named "GuestButton"
#     - A Label named "StatusLabel"
#     - A Panel or AnimationPlayer for show/hide (optional)
# ==============================================================================

extends Control

# ── Node References ───────────────────────────────────────────────────────────
@onready var play_games_button: Button = $PlayGamesButton
@onready var guest_button: Button     = $GuestButton
@onready var status_label: Label      = $StatusLabel

# ── Lifecycle ─────────────────────────────────────────────────────────────────
func _ready() -> void:
	_connect_auth_signals()
	_connect_button_signals()
	_set_status("Choose how to sign in")


# ── Signal Wiring ─────────────────────────────────────────────────────────────
func _connect_auth_signals() -> void:
	AuthFlowManager.auth_succeeded.connect(_on_auth_succeeded)
	AuthFlowManager.auth_failed.connect(_on_auth_failed)
	AuthFlowManager.auth_state_changed.connect(_on_auth_state_changed)


func _connect_button_signals() -> void:
	play_games_button.pressed.connect(_on_play_games_pressed)
	guest_button.pressed.connect(_on_guest_pressed)


# ── Button Handlers ───────────────────────────────────────────────────────────
func _on_play_games_pressed() -> void:
	_set_loading(true, "Connecting to Play Games...")
	var success = await AuthFlowManager.sign_in_with_play_games()
	if not success:
		_set_loading(false)
		# auth_failed signal will update the label


func _on_guest_pressed() -> void:
	_set_loading(true, "Signing in as Guest...")
	var success = await AuthFlowManager.sign_in_anonymously()
	if not success:
		_set_loading(false)


# ── Auth Callbacks ────────────────────────────────────────────────────────────
func _on_auth_succeeded(user_data: Dictionary) -> void:
	_set_loading(false)
	var name = user_data.get("display_name", "Player")
	_set_status("Welcome, %s!" % name)
	# Navigate to your main menu / game scene here:
	# get_tree().change_scene_to_file("res://Scenes/MainMenu.tscn")
	hide()


func _on_auth_failed(reason: String) -> void:
	_set_loading(false)
	_set_status("Sign-in failed: " + reason)


func _on_auth_state_changed(is_signed_in: bool) -> void:
	play_games_button.disabled = is_signed_in
	guest_button.disabled = is_signed_in


# ── UI Helpers ────────────────────────────────────────────────────────────────
func _set_loading(loading: bool, message: String = "") -> void:
	play_games_button.disabled = loading
	guest_button.disabled = loading
	if loading and not message.is_empty():
		_set_status(message)


func _set_status(text: String) -> void:
	if status_label:
		status_label.text = text
